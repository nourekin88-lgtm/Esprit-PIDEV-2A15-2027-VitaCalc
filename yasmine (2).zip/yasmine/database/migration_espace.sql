-- À exécuter UNE SEULE FOIS si la base yasmine_db existe déjà
USE yasmine_db;
ALTER TABLE programme ADD COLUMN categorie ENUM('perte_poids','prise_masse','endurance','tonification','remise_en_forme') NOT NULL DEFAULT 'remise_en_forme' AFTER objectif;
ALTER TABLE exercice  ADD COLUMN description VARCHAR(150) NULL AFTER nom;
ALTER TABLE exercice  ADD COLUMN image VARCHAR(255) NULL AFTER repetitions;
