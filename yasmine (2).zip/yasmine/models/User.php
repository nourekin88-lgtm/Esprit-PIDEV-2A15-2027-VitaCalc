<?php
class User {
    private PDO $db;
    public function __construct() { $this->db = Database::getConnection(); }

    public function findByEmail(string $email): array|false {
        $st = $this->db->prepare("SELECT * FROM utilisateur WHERE email = ?");
        $st->execute([$email]);
        return $st->fetch();
    }

    public function emailExists(string $email): bool {
        $st = $this->db->prepare("SELECT COUNT(*) FROM utilisateur WHERE email = ?");
        $st->execute([$email]);
        return $st->fetchColumn() > 0;
    }

    public function create(array $d): bool {
        $st = $this->db->prepare(
            "INSERT INTO utilisateur (nom, email, mot_de_passe, objectif)
             VALUES (:nom, :email, :mdp, :objectif)");
        return $st->execute([
            ':nom' => $d['nom'],
            ':email' => $d['email'],
            ':mdp' => password_hash($d['mot_de_passe'], PASSWORD_DEFAULT),
            ':objectif' => $d['objectif'],
        ]);
    }
}
