<?php
class Controller {
    protected function render(string $view, array $data = [], string $layout = 'front'): void {
        extract($data);
        ob_start();
        require __DIR__ . "/../views/$view.php";
        $content = ob_get_clean();
        require __DIR__ . "/../views/layouts/$layout.php";
    }

    protected function redirect(string $url): void {
        header("Location: $url");
        exit;
    }
}

function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
