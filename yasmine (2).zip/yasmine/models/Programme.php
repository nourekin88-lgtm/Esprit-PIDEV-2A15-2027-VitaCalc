<?php
class Programme {
    public const CATEGORIES = [
        'perte_poids'     => 'Perte de poids',
        'prise_masse'     => 'Prise de masse',
        'endurance'       => 'Endurance',
        'tonification'    => 'Tonification',
        'remise_en_forme' => 'Remise en forme',
    ];

    private PDO $db;
    public function __construct() { $this->db = Database::getConnection(); }

    public function all(): array {
        return $this->db->query("SELECT * FROM programme ORDER BY id DESC")->fetchAll();
    }

    public function find(int $id): array|false {
        $st = $this->db->prepare("SELECT * FROM programme WHERE id = ?");
        $st->execute([$id]);
        return $st->fetch();
    }

    public function create(array $d): bool {
        $st = $this->db->prepare(
            "INSERT INTO programme (nom, objectif, categorie, niveau, duree_semaines)
             VALUES (:nom, :objectif, :cat, :niveau, :duree)");
        return $st->execute([
            ':nom' => $d['nom'], ':objectif' => $d['objectif'], ':cat' => $d['categorie'],
            ':niveau' => $d['niveau'], ':duree' => $d['duree_semaines'],
        ]);
    }

    public function update(int $id, array $d): bool {
        $st = $this->db->prepare(
            "UPDATE programme SET nom=:nom, objectif=:objectif, categorie=:cat, niveau=:niveau,
             duree_semaines=:duree WHERE id=:id");
        return $st->execute([
            ':nom' => $d['nom'], ':objectif' => $d['objectif'], ':cat' => $d['categorie'],
            ':niveau' => $d['niveau'], ':duree' => $d['duree_semaines'], ':id' => $id,
        ]);
    }

    public function delete(int $id): bool {
        $st = $this->db->prepare("DELETE FROM programme WHERE id = ?");
        return $st->execute([$id]);
    }

    // Jointure agrégée : nombre d'exercices + totaux
    public function allWithStats(): array {
        $sql = "SELECT p.*, COUNT(e.id) AS nb_exercices,
                       COALESCE(SUM(e.duree_minutes),0) AS total_minutes,
                       COALESCE(SUM(e.calories),0) AS total_calories
                FROM programme p LEFT JOIN exercice e ON e.id_programme = p.id
                GROUP BY p.id ORDER BY p.id DESC";
        return $this->db->query($sql)->fetchAll();
    }

    // RÈGLE MÉTIER AVANCÉE : recommandation selon objectif, niveau et temps disponible
    public function recommend(string $categorie, string $niveau, int $minutes): array {
        $sql = "SELECT p.*, COUNT(e.id) AS nb_exercices,
                       COALESCE(SUM(e.duree_minutes),0) AS total_minutes,
                       COALESCE(SUM(e.calories),0) AS total_calories
                FROM programme p LEFT JOIN exercice e ON e.id_programme = p.id
                WHERE p.categorie = :c AND p.niveau = :n
                GROUP BY p.id
                HAVING nb_exercices > 0 AND total_minutes <= :m
                ORDER BY total_minutes DESC";
        $st = $this->db->prepare($sql);
        $st->execute([':c' => $categorie, ':n' => $niveau, ':m' => $minutes]);
        return $st->fetchAll();
    }

    public function countExercices(int $id): int {
        $st = $this->db->prepare("SELECT COUNT(*) FROM exercice WHERE id_programme = ?");
        $st->execute([$id]);
        return (int)$st->fetchColumn();
    }

    public function nomExists(string $nom, int $exceptId = 0): bool {
        $st = $this->db->prepare("SELECT COUNT(*) FROM programme WHERE nom = ? AND id <> ?");
        $st->execute([$nom, $exceptId]);
        return $st->fetchColumn() > 0;
    }
}
