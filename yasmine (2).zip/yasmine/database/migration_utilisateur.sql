USE yasmine_db;
CREATE TABLE IF NOT EXISTS utilisateur (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  mot_de_passe VARCHAR(255) NOT NULL,
  objectif ENUM('perte_poids','prise_masse','endurance','tonification','remise_en_forme') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
