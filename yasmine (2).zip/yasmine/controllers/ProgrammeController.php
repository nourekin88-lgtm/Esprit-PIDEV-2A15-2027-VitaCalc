<?php
class ProgrammeController extends Controller {
    private Programme $model;
    public function __construct() { $this->model = new Programme(); }

    public function index(): void {
        $this->render('back/programme/index', ['items' => $this->model->allWithStats()], 'back');
    }

    public function create(): void {
        $this->render('back/programme/form',
            ['item' => [], 'errors' => [], 'action' => 'index.php?area=admin&c=programme&a=store'], 'back');
    }

    public function store(): void {
        $d = $this->clean();
        $errors = $this->validate($d);
        if ($errors) {
            $this->render('back/programme/form', ['item' => $d, 'errors' => $errors,
                'action' => 'index.php?area=admin&c=programme&a=store'], 'back');
            return;
        }
        $this->model->create($d);
        $this->redirect('index.php?area=admin&c=programme');
    }

    public function edit(): void {
        $id = (int)($_GET['id'] ?? 0);
        $item = $this->model->find($id);
        if (!$item) $this->redirect('index.php?area=admin&c=programme');
        $this->render('back/programme/form', ['item' => $item, 'errors' => [],
            'action' => "index.php?area=admin&c=programme&a=update&id=$id"], 'back');
    }

    public function update(): void {
        $id = (int)($_GET['id'] ?? 0);
        $d = $this->clean();
        $errors = $this->validate($d, $id);
        if ($errors) {
            $this->render('back/programme/form', ['item' => $d, 'errors' => $errors,
                'action' => "index.php?area=admin&c=programme&a=update&id=$id"], 'back');
            return;
        }
        $this->model->update($id, $d);
        $this->redirect('index.php?area=admin&c=programme');
    }

    public function delete(): void {
        $id = (int)($_POST['id'] ?? 0);
        // Règle métier : on ne supprime pas un programme qui contient des exercices
        if ($this->model->countExercices($id) > 0) {
            $this->redirect('index.php?area=admin&c=programme&error=has_exercices');
        }
        $this->model->delete($id);
        $this->redirect('index.php?area=admin&c=programme');
    }

    private function clean(): array {
        return [
            'nom'            => trim($_POST['nom'] ?? ''),
            'objectif'       => trim($_POST['objectif'] ?? ''),
            'niveau'         => $_POST['niveau'] ?? '',
            'categorie'      => $_POST['categorie'] ?? '',
            'duree_semaines' => trim($_POST['duree_semaines'] ?? ''),
        ];
    }

    private function validate(array $d, int $id = 0): array {
        $e = [];
        if (strlen($d['nom']) < 3 || strlen($d['nom']) > 100) $e['nom'] = "Le nom doit contenir entre 3 et 100 caractères.";
        elseif ($this->model->nomExists($d['nom'], $id)) $e['nom'] = "Ce nom de programme existe déjà.";
        if (strlen($d['objectif']) < 5) $e['objectif'] = "L'objectif doit contenir au moins 5 caractères.";
        if (!in_array($d['niveau'], ['debutant', 'intermediaire', 'avance'], true)) $e['niveau'] = "Niveau invalide.";
        if (!array_key_exists($d['categorie'], Programme::CATEGORIES)) $e['categorie'] = "Catégorie invalide.";
        if (!ctype_digit($d['duree_semaines']) || $d['duree_semaines'] < 1 || $d['duree_semaines'] > 52)
            $e['duree_semaines'] = "La durée doit être un entier entre 1 et 52 semaines.";
        return $e;
    }
}
