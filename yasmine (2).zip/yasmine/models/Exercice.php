<?php
class Exercice {
    private PDO $db;
    public function __construct() { $this->db = Database::getConnection(); }

    // JOINTURE exercice + programme
    public function allWithProgramme(string $search = ''): array {
        $sql = "SELECT e.*, p.nom AS programme_nom
                FROM exercice e INNER JOIN programme p ON e.id_programme = p.id
                WHERE e.nom LIKE :s ORDER BY e.id DESC";
        $st = $this->db->prepare($sql);
        $st->execute([':s' => "%$search%"]);
        return $st->fetchAll();
    }

    public function byProgramme(int $idProgramme): array {
        $st = $this->db->prepare("SELECT * FROM exercice WHERE id_programme = ? ORDER BY id");
        $st->execute([$idProgramme]);
        return $st->fetchAll();
    }

    public function find(int $id): array|false {
        $st = $this->db->prepare("SELECT * FROM exercice WHERE id = ?");
        $st->execute([$id]);
        return $st->fetch();
    }

    public function create(array $d): bool {
        $st = $this->db->prepare(
            "INSERT INTO exercice (nom, description, type, duree_minutes, calories, series, repetitions, image, id_programme)
             VALUES (:nom,:desc,:type,:duree,:cal,:series,:reps,:img,:prog)");
        return $st->execute($this->params($d));
    }

    public function update(int $id, array $d): bool {
        $st = $this->db->prepare(
            "UPDATE exercice SET nom=:nom, description=:desc, type=:type, duree_minutes=:duree, calories=:cal,
             series=:series, repetitions=:reps, image=:img, id_programme=:prog WHERE id=:id");
        return $st->execute($this->params($d) + [':id' => $id]);
    }

    public function delete(int $id): bool {
        $st = $this->db->prepare("DELETE FROM exercice WHERE id = ?");
        return $st->execute([$id]);
    }

    public function nomExistsInProgramme(string $nom, int $idProg, int $exceptId = 0): bool {
        $st = $this->db->prepare(
            "SELECT COUNT(*) FROM exercice WHERE nom=? AND id_programme=? AND id<>?");
        $st->execute([$nom, $idProg, $exceptId]);
        return $st->fetchColumn() > 0;
    }

    private function params(array $d): array {
        return [
            ':nom' => $d['nom'],
            ':desc' => ($d['description'] ?? '') !== '' ? $d['description'] : null,
            ':type' => $d['type'], ':duree' => $d['duree_minutes'],
            ':cal' => $d['calories'], ':series' => $d['series'],
            ':reps' => $d['repetitions'],
            ':img' => $d['image'] ?? null,
            ':prog' => $d['id_programme'],
        ];
    }
}
