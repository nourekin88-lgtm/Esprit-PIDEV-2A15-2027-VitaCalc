<div class="container page">
  <a class="muted" href="index.php#decouvrir">← Retour aux programmes</a>
  <span class="eyebrow" style="display:block;margin-top:18px">PROGRAMME · <?= e(strtoupper($programme['niveau'])) ?></span>
  <h1><?= e($programme['nom']) ?></h1>
  <p class="muted"><?= e($programme['objectif']) ?> · <?= $programme['duree_semaines'] ?> semaines</p>
  <?php if (!$exercices): ?>
    <p class="muted">Aucun exercice pour le moment.</p>
  <?php else: ?>
  <table>
    <tr><th>Exercice</th><th>Type</th><th>Durée</th><th>Calories</th><th>Séries × Reps</th></tr>
    <?php foreach ($exercices as $x): ?>
    <tr>
      <td><?= e($x['nom']) ?></td><td><span class="tag"><?= e($x['type']) ?></span></td>
      <td><?= $x['duree_minutes'] ?> min</td><td><?= $x['calories'] ?></td>
      <td><?= $x['series'] ?> × <?= $x['repetitions'] ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>
</div>
