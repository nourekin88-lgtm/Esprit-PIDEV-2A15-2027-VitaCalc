<?php
$typeLabel = ['cardio' => 'Cardio', 'musculation' => 'Force', 'etirement' => 'Souplesse'];
$typeIcon  = ['cardio' => '🏃', 'musculation' => '🏋️', 'etirement' => '🧘'];
$niveauLabel = EspaceController::NIVEAUX;
?>
<div class="container page">

  <section class="welcome">
    <div>
      <span class="eyebrow">TON ESPACE SPORTIF</span>
      <h1>Bienvenue, <em><?= e($_SESSION['user']['nom']) ?></em> !</h1>
      <p class="muted">Aujourd'hui est une nouvelle occasion de progresser.</p>
    </div>
    <a class="btn-outline" href="index.php?c=auth&a=logout">Déconnexion</a>
  </section>

  <section class="panel">
    <span class="eyebrow">PERSONNALISE TON ENTRAÎNEMENT</span>
    <h2>Mon profil sportif</h2>
    <form method="get" action="index.php#mes-programmes" class="profile-form">
      <input type="hidden" name="c" value="espace">
      <label>Objectif
        <select name="objectif">
          <?php foreach (Programme::CATEGORIES as $k => $v): ?>
            <option value="<?= $k ?>" <?= $profil['objectif'] === $k ? 'selected' : '' ?>><?= e($v) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Niveau
        <select name="niveau">
          <?php foreach (EspaceController::NIVEAUX as $k => $v): ?>
            <option value="<?= $k ?>" <?= $profil['niveau'] === $k ? 'selected' : '' ?>><?= e($v) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Temps disponible
        <select name="temps">
          <?php foreach (EspaceController::TEMPS as $k => $v): ?>
            <option value="<?= $k ?>" <?= (int)$profil['temps'] === $k ? 'selected' : '' ?>><?= e($v) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <button class="btn">Trouver mon programme</button>
    </form>
  </section>

  <section class="panel" id="exercices">
    <span class="eyebrow">BOUGE ET PROGRESSE</span>
    <h2>Les exercices</h2>
    <div class="filters">
      <button type="button" class="active" data-filter="all">Tout</button>
      <button type="button" data-filter="cardio">Cardio</button>
      <button type="button" data-filter="musculation">Force</button>
      <button type="button" data-filter="etirement">Souplesse</button>
    </div>
    <?php if (!$exercices): ?>
      <p class="muted">Aucun exercice pour le moment.</p>
    <?php endif; ?>
    <div class="ex-grid">
      <?php foreach ($exercices as $x): ?>
      <a class="ex-card" data-type="<?= e($x['type']) ?>" href="index.php?c=front&a=show&id=<?= (int)$x['id_programme'] ?>">
        <?php if (!empty($x['image'])): ?>
          <div class="ex-img" style="background-image:url('<?= e($x['image']) ?>')"></div>
        <?php else: ?>
          <div class="ex-img ph ph-<?= e($x['type']) ?>"><span><?= $typeIcon[$x['type']] ?? '💪' ?></span></div>
        <?php endif; ?>
        <div class="ex-body">
          <span class="tag"><?= $typeLabel[$x['type']] ?? e($x['type']) ?></span>
          <h4><?= e($x['nom']) ?></h4>
          <p class="muted"><?= e($x['description'] ?? '') ?></p>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="panel" id="mes-programmes">
    <span class="eyebrow">PASSE À L'ACTION</span>
    <h2><?= $recherche ? 'Programmes recommandés pour toi' : 'Mes programmes' ?></h2>
    <?php if (!$programmes): ?>
      <p class="muted">Aucun programme ne correspond à ton profil pour le moment. Essaie un autre niveau ou plus de temps.</p>
    <?php endif; ?>
    <div class="prog-grid">
      <?php foreach ($programmes as $p): ?>
      <div class="prog-card">
        <span class="tag"><?= $niveauLabel[$p['niveau']] ?? e($p['niveau']) ?></span>
        <h4><?= e($p['nom']) ?></h4>
        <p class="muted small"><?= e($p['objectif']) ?></p>
        <p class="muted small">⏱ <?= (int)$p['total_minutes'] ?> minutes<br><?= (int)$p['nb_exercices'] ?> exercices</p>
        <a class="btn" href="index.php?c=front&a=show&id=<?= (int)$p['id'] ?>">Démarrer →</a>
      </div>
      <?php endforeach; ?>
    </div>
  </section>
</div>
<script src="public/js/espace.js"></script>
