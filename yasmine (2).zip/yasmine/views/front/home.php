<?php
$nbProg = count($programmes);
$nbEx   = array_sum(array_column($programmes, 'nb_exercices'));
$heroImg = file_exists(__DIR__ . '/../../public/img/hero.jpg') ? 'public/img/hero.jpg' : '';
?>
<section class="hero">
  <div class="container hero-in">
    <div class="hero-text">
      <span class="pill"><i></i> Your Health. Your Balance.</span>
      <h1>Bougez mieux,<br><em>vivez plus fort.</em></h1>
      <p>Découvrez des exercices adaptés à vos objectifs, des programmes sportifs et un suivi simple pour améliorer votre forme chaque jour.</p>
      <div class="hero-btns">
        <a class="btn" href="#pourquoi">Savoir plus →</a>
        <a class="btn-outline" href="#decouvrir">Découvrir Yasmine</a>
      </div>
      <div class="stats">
        <div><b><?= $nbEx ?>+</b><span>Exercices</span></div>
        <div><b><?= $nbProg ?></b><span>Programmes</span></div>
        <div><b>100%</b><span>Motivation</span></div>
      </div>
    </div>
    <div class="hero-img" <?= $heroImg ? 'style="background-image:url(\'' . $heroImg . '\')"' : '' ?>>
      <div class="hero-chip"><span class="bolt">⚡</span><div><b>Ton objectif</b><small>Commence aujourd'hui</small></div></div>
    </div>
  </div>
</section>

<section class="section alt" id="pourquoi">
  <div class="container center">
    <span class="eyebrow">POURQUOI YASMINE ?</span>
    <h2>Le sport, <em>à ta façon.</em></h2>
    <p class="muted">Tout ce dont tu as besoin pour progresser.</p>
    <div class="features">
      <div class="feature"><div class="ico">🎯</div><h4>Objectifs personnalisés</h4><p>Choisis ton objectif sportif et découvre un programme adapté.</p></div>
      <div class="feature"><div class="ico">💪</div><h4>Exercices efficaces</h4><p>Découvre différents exercices avec des explications simples.</p></div>
      <div class="feature"><div class="ico">⏱️</div><h4>Séances chronométrées</h4><p>Organise tes séances et suis ton rythme d'entraînement.</p></div>
    </div>
    <div class="cta">
      <div><span class="eyebrow">TON AVENTURE COMMENCE ICI</span><h3>Prêt à atteindre tes objectifs ?</h3></div>
      <a class="btn" href="index.php?c=auth&a=register">Commencer maintenant →</a>
    </div>
  </div>
</section>

<section class="section" id="decouvrir">
  <div class="container">
    <span class="eyebrow">NOS PROGRAMMES</span>
    <h2>Choisis ton <em>programme</em></h2>
    <div class="cards">
      <?php foreach ($programmes as $p): ?>
      <div class="card">
        <span class="tag"><?= e($p['niveau']) ?></span>
        <h3><?= e($p['nom']) ?></h3>
        <p class="muted"><?= e($p['objectif']) ?></p>
        <p class="meta"><?= $p['duree_semaines'] ?> semaines · <?= $p['nb_exercices'] ?> exercices · <?= $p['total_minutes'] ?> min · <?= $p['total_calories'] ?> kcal</p>
        <a class="btn" href="index.php?c=front&a=show&id=<?= $p['id'] ?>">Voir les exercices →</a>
      </div>
      <?php endforeach; ?>
      <?php if (!$programmes): ?><p class="muted">Aucun programme pour le moment.</p><?php endif; ?>
    </div>
  </div>
</section>
