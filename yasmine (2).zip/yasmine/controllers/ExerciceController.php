<?php
class ExerciceController extends Controller {
    private Exercice $model;
    private Programme $programmes;

    public function __construct() {
        $this->model = new Exercice();
        $this->programmes = new Programme();
    }

    public function index(): void {
        $search = trim($_GET['q'] ?? '');
        $this->render('back/exercice/index',
            ['items' => $this->model->allWithProgramme($search), 'search' => $search], 'back');
    }

    public function create(): void { $this->form([], [], 'store'); }

    public function store(): void {
        $d = $this->clean();
        $d['image'] = null;
        $errors = $this->validate($d);
        if (!$errors) $d['image'] = $this->uploadImage($errors);
        if ($errors) { $d['image'] = null; $this->form($d, $errors, 'store'); return; }
        $this->model->create($d);
        $this->redirect('index.php?area=admin&c=exercice');
    }

    public function edit(): void {
        $id = (int)($_GET['id'] ?? 0);
        $item = $this->model->find($id);
        if (!$item) $this->redirect('index.php?area=admin&c=exercice');
        $this->form($item, [], "update&id=$id");
    }

    public function update(): void {
        $id = (int)($_GET['id'] ?? 0);
        $old = $this->model->find($id);
        if (!$old) $this->redirect('index.php?area=admin&c=exercice');

        $d = $this->clean();
        $d['image'] = $old['image'];
        $errors = $this->validate($d, $id);
        $new = null;
        if (!$errors) {
            $new = $this->uploadImage($errors);
            if ($new) $d['image'] = $new;
        }
        if ($errors) { $d['image'] = $old['image']; $this->form($d, $errors, "update&id=$id"); return; }

        $this->model->update($id, $d);
        if ($new) $this->deleteFile($old['image']);
        $this->redirect('index.php?area=admin&c=exercice');
    }

    public function delete(): void {
        $id = (int)($_POST['id'] ?? 0);
        $old = $this->model->find($id);
        $this->model->delete($id);
        if ($old) $this->deleteFile($old['image']);
        $this->redirect('index.php?area=admin&c=exercice');
    }

    private function form(array $item, array $errors, string $action): void {
        $this->render('back/exercice/form', [
            'item' => $item, 'errors' => $errors,
            'programmes' => $this->programmes->all(),
            'action' => "index.php?area=admin&c=exercice&a=$action",
        ], 'back');
    }

    private function clean(): array {
        return [
            'nom'           => trim($_POST['nom'] ?? ''),
            'description'   => trim($_POST['description'] ?? ''),
            'type'          => $_POST['type'] ?? '',
            'duree_minutes' => trim($_POST['duree_minutes'] ?? ''),
            'calories'      => trim($_POST['calories'] ?? ''),
            'series'        => trim($_POST['series'] ?? ''),
            'repetitions'   => trim($_POST['repetitions'] ?? ''),
            'id_programme'  => trim($_POST['id_programme'] ?? ''),
        ];
    }

    private function validate(array $d, int $id = 0): array {
        $e = [];
        if (strlen($d['nom']) < 3 || strlen($d['nom']) > 100) $e['nom'] = "Le nom doit contenir entre 3 et 100 caractères.";
        if (mb_strlen($d['description']) > 150) $e['description'] = "Description : 150 caractères maximum.";
        if (!in_array($d['type'], ['cardio', 'musculation', 'etirement'], true)) $e['type'] = "Type invalide.";
        if (!ctype_digit($d['duree_minutes']) || $d['duree_minutes'] < 1 || $d['duree_minutes'] > 300)
            $e['duree_minutes'] = "Durée : entier entre 1 et 300 minutes.";
        if (!ctype_digit($d['calories']) || $d['calories'] > 3000) $e['calories'] = "Calories : entier entre 0 et 3000.";
        if (!ctype_digit($d['series']) || $d['series'] < 1 || $d['series'] > 20) $e['series'] = "Séries : entre 1 et 20.";
        if (!ctype_digit($d['repetitions']) || $d['repetitions'] < 1 || $d['repetitions'] > 100) $e['repetitions'] = "Répétitions : entre 1 et 100.";
        if (!ctype_digit($d['id_programme']) || !$this->programmes->find((int)$d['id_programme']))
            $e['id_programme'] = "Veuillez choisir un programme valide.";
        elseif (!isset($e['nom']) && $this->model->nomExistsInProgramme($d['nom'], (int)$d['id_programme'], $id))
            $e['nom'] = "Cet exercice existe déjà dans ce programme.";
        return $e;
    }

    // Retourne le chemin de l'image enregistrée, ou null (si aucun fichier ou erreur)
    private function uploadImage(array &$errors): ?string {
        if (empty($_FILES['image']['name'])) return null;
        $f = $_FILES['image'];
        if ($f['error'] !== UPLOAD_ERR_OK) { $errors['image'] = "Échec de l'envoi de l'image."; return null; }
        if ($f['size'] > 2 * 1024 * 1024) { $errors['image'] = "Image trop lourde (2 Mo maximum)."; return null; }
        $info = @getimagesize($f['tmp_name']);
        $allowed = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
        if (!$info || !isset($allowed[$info[2]])) { $errors['image'] = "Format accepté : JPG, PNG ou WEBP."; return null; }

        $dir = __DIR__ . '/../public/uploads';
        if (!is_dir($dir)) mkdir($dir, 0775, true);
        $name = 'ex_' . bin2hex(random_bytes(6)) . '.' . $allowed[$info[2]];
        if (!move_uploaded_file($f['tmp_name'], "$dir/$name")) { $errors['image'] = "Impossible d'enregistrer l'image."; return null; }
        return 'public/uploads/' . $name;
    }

    private function deleteFile(?string $path): void {
        if ($path && str_starts_with($path, 'public/uploads/')) @unlink(__DIR__ . '/../' . $path);
    }
}
