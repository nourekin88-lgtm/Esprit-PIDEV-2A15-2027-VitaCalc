<h1><?= str_contains($action, 'update') ? 'Modifier' : 'Nouvel' ?> exercice</h1>
<form method="post" action="<?= e($action) ?>" enctype="multipart/form-data" data-validate novalidate>
  <label>Nom
    <input type="text" name="nom" value="<?= e($item['nom'] ?? '') ?>" required minlength="3" maxlength="100">
    <small class="error"><?= $errors['nom'] ?? '' ?></small>
  </label>
  <label>Description (groupe musculaire, optionnel)
    <input type="text" name="description" placeholder="Ex : Jambes et fessiers" value="<?= e($item['description'] ?? '') ?>" maxlength="150">
    <small class="error"><?= $errors['description'] ?? '' ?></small>
  </label>
  <label>Type
    <select name="type" required>
      <option value="">-- Choisir --</option>
      <?php foreach (['cardio' => 'Cardio', 'musculation' => 'Musculation (Force)', 'etirement' => 'Étirement (Souplesse)'] as $k => $v): ?>
        <option value="<?= $k ?>" <?= ($item['type'] ?? '') === $k ? 'selected' : '' ?>><?= $v ?></option>
      <?php endforeach; ?>
    </select>
    <small class="error"><?= $errors['type'] ?? '' ?></small>
  </label>
  <label>Durée (minutes)
    <input type="number" name="duree_minutes" value="<?= e($item['duree_minutes'] ?? '') ?>" required min="1" max="300">
    <small class="error"><?= $errors['duree_minutes'] ?? '' ?></small>
  </label>
  <label>Calories brûlées
    <input type="number" name="calories" value="<?= e($item['calories'] ?? '0') ?>" required min="0" max="3000">
    <small class="error"><?= $errors['calories'] ?? '' ?></small>
  </label>
  <label>Séries
    <input type="number" name="series" value="<?= e($item['series'] ?? '1') ?>" required min="1" max="20">
    <small class="error"><?= $errors['series'] ?? '' ?></small>
  </label>
  <label>Répétitions
    <input type="number" name="repetitions" value="<?= e($item['repetitions'] ?? '1') ?>" required min="1" max="100">
    <small class="error"><?= $errors['repetitions'] ?? '' ?></small>
  </label>
  <label>Programme
    <select name="id_programme" required>
      <option value="">-- Choisir --</option>
      <?php foreach ($programmes as $p): ?>
        <option value="<?= $p['id'] ?>" <?= ($item['id_programme'] ?? '') == $p['id'] ? 'selected' : '' ?>><?= e($p['nom']) ?></option>
      <?php endforeach; ?>
    </select>
    <small class="error"><?= $errors['id_programme'] ?? '' ?></small>
  </label>
  <label>Image de l'exercice (JPG, PNG, WEBP – 2 Mo max)
    <input type="file" name="image" accept="image/jpeg,image/png,image/webp">
    <small class="error"><?= $errors['image'] ?? '' ?></small>
  </label>
  <?php if (!empty($item['image'])): ?>
    <p class="muted small">Image actuelle (laisser vide pour la conserver) :</p>
    <img class="thumb big" src="<?= e($item['image']) ?>" alt="">
  <?php endif; ?>
  <div style="margin-top:14px">
    <button class="btn">Enregistrer</button>
    <a href="index.php?area=admin&c=exercice">Annuler</a>
  </div>
</form>
