<?php
session_start();
require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/core/Controller.php';

spl_autoload_register(function ($class) {
    foreach (['controllers', 'models'] as $dir) {
        $file = __DIR__ . "/$dir/$class.php";
        if (file_exists($file)) { require_once $file; return; }
    }
});

$area = $_GET['area'] ?? 'front';           // front | admin
$ctrl = $_GET['c'] ?? ($area === 'admin' ? 'programme' : 'front');
$act  = $_GET['a'] ?? 'index';

$class = ucfirst($ctrl) . 'Controller';
if (!preg_match('/^[a-zA-Z]+$/', $ctrl) || !class_exists($class) || str_starts_with($act, '__')) {
    http_response_code(404);
    exit('Page introuvable');
}
$obj = new $class();
if (!is_callable([$obj, $act])) {
    http_response_code(404);
    exit('Page introuvable');
}
$obj->$act();
