document.querySelectorAll('form[data-validate]').forEach(form => {
  form.addEventListener('submit', e => {
    let valid = true;
    form.querySelectorAll('input, select').forEach(field => {
      if (field.type === 'hidden') return;
      const label = field.closest('label');
      const msg = label ? label.querySelector('.error') : null;
      let error = '';
      const v = field.type === 'password' ? field.value : field.value.trim();

      if (field.required && v === '') error = 'Ce champ est obligatoire.';
      else if (field.minLength > 0 && v.length < field.minLength)
        error = `Minimum ${field.minLength} caractères.`;
      else if (field.type === 'email' && v !== '' && !/^\S+@\S+\.\S+$/.test(v))
        error = 'Adresse e-mail invalide.';
      else if (field.type === 'number' && v !== '') {
        if (field.min !== '' && Number(v) < Number(field.min)) error = `Valeur minimale : ${field.min}.`;
        if (field.max !== '' && Number(v) > Number(field.max)) error = `Valeur maximale : ${field.max}.`;
      }
      if (msg) msg.textContent = error;
      if (error) valid = false;
    });
    if (!valid) e.preventDefault();
  });
});
