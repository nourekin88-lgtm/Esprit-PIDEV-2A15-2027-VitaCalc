<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Yasmine – Administration</title>
  <link rel="stylesheet" href="public/css/style.css">
</head>
<body class="admin">
<header class="topbar">
  <div class="container topbar-in">
    <a class="logo" href="index.php?area=admin"><span class="logo-badge">Y</span> Admin Yasmine</a>
    <nav class="menu">
      <a href="index.php?area=admin&c=programme">Programmes</a>
      <a href="index.php?area=admin&c=exercice">Exercices</a>
    </nav>
    <a class="btn-outline" href="index.php">← Front Office</a>
  </div>
</header>
<main class="container page"><?= $content ?></main>
<script src="public/js/validation.js"></script>
</body>
</html>
