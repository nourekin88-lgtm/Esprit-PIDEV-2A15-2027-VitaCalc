<h1>Programmes</h1>
<?php if (($_GET['error'] ?? '') === 'has_exercices'): ?>
  <p class="error">Impossible de supprimer : ce programme contient des exercices.</p>
<?php endif; ?>
<a class="btn" href="index.php?area=admin&c=programme&a=create">+ Nouveau programme</a>
<table>
  <tr><th>ID</th><th>Nom</th><th>Niveau</th><th>Durée</th><th>Exercices</th><th>Total min</th><th>Total kcal</th><th>Actions</th></tr>
  <?php foreach ($items as $p): ?>
  <tr>
    <td><?= $p['id'] ?></td>
    <td><?= e($p['nom']) ?></td>
    <td><?= e($p['niveau']) ?></td>
    <td><?= $p['duree_semaines'] ?> sem.</td>
    <td><?= $p['nb_exercices'] ?></td>
    <td><?= $p['total_minutes'] ?></td>
    <td><?= $p['total_calories'] ?></td>
    <td>
      <a href="index.php?area=admin&c=programme&a=edit&id=<?= $p['id'] ?>">Modifier</a>
      <form method="post" action="index.php?area=admin&c=programme&a=delete" style="display:inline"
            onsubmit="return confirm('Supprimer ce programme ?')">
        <input type="hidden" name="id" value="<?= $p['id'] ?>">
        <button class="danger">Supprimer</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
