<?php
class FrontController extends Controller {
    public function index(): void {
        $this->render('front/home', ['programmes' => (new Programme())->allWithStats()], 'front');
    }

    public function show(): void {
        $id = (int)($_GET['id'] ?? 0);
        $programme = (new Programme())->find($id);
        if (!$programme) $this->redirect('index.php');
        $this->render('front/show', [
            'programme' => $programme,
            'exercices' => (new Exercice())->byProgramme($id),
        ], 'front');
    }
}
