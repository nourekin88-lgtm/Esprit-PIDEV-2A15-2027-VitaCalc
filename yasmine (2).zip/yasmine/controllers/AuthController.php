<?php
class AuthController extends Controller {
    public const OBJECTIFS = Programme::CATEGORIES;

    private User $model;
    public function __construct() { $this->model = new User(); }

    public function register(): void {
        $item = [];
        $errors = [];
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $item = [
                'nom'          => trim($_POST['nom'] ?? ''),
                'email'        => strtolower(trim($_POST['email'] ?? '')),
                'mot_de_passe' => $_POST['mot_de_passe'] ?? '',
                'objectif'     => $_POST['objectif'] ?? '',
            ];
            $errors = $this->validateRegister($item);
            if (!$errors) {
                $this->model->create($item);
                $this->redirect('index.php?c=auth&a=login&registered=1');
            }
            $item['mot_de_passe'] = '';
        }
        $this->render('auth/register',
            ['item' => $item, 'errors' => $errors, 'objectifs' => self::OBJECTIFS], 'front');
    }

    public function login(): void {
        $email = '';
        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = strtolower(trim($_POST['email'] ?? ''));
            $user = $this->model->findByEmail($email);
            if ($user && password_verify($_POST['mot_de_passe'] ?? '', $user['mot_de_passe'])) {
                session_regenerate_id(true);
                $_SESSION['user'] = ['id' => $user['id'], 'nom' => $user['nom'], 'objectif' => $user['objectif']];
                $this->redirect('index.php?c=espace');
            }
            $error = 'E-mail ou mot de passe incorrect.';
        }
        $this->render('auth/login', ['email' => $email, 'error' => $error], 'front');
    }

    public function logout(): void {
        $_SESSION = [];
        session_destroy();
        $this->redirect('index.php');
    }

    private function validateRegister(array $d): array {
        $e = [];
        if (mb_strlen($d['nom']) < 3 || mb_strlen($d['nom']) > 100)
            $e['nom'] = "Le nom doit contenir entre 3 et 100 caractères.";
        if (!filter_var($d['email'], FILTER_VALIDATE_EMAIL))
            $e['email'] = "Adresse e-mail invalide.";
        elseif ($this->model->emailExists($d['email']))
            $e['email'] = "Cet e-mail est déjà utilisé.";
        if (strlen($d['mot_de_passe']) < 6)
            $e['mot_de_passe'] = "Le mot de passe doit contenir au moins 6 caractères.";
        if (!array_key_exists($d['objectif'], self::OBJECTIFS))
            $e['objectif'] = "Veuillez choisir un objectif.";
        return $e;
    }
}
