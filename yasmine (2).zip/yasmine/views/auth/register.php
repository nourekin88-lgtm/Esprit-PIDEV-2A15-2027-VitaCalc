<?php $img = file_exists(__DIR__ . '/../../public/img/register.jpg') ? 'public/img/register.jpg' : ''; ?>
<section class="auth">
  <div class="container auth-in">
    <div class="auth-img" <?= $img ? 'style="background-image:url(\'' . $img . '\')"' : '' ?>>
      <div class="auth-cap">
        <h3>Chaque effort<br>te rapproche de ton objectif.</h3>
        <small>Your Health, Your Balance.</small>
      </div>
    </div>
    <div class="auth-form">
      <a class="muted small" href="index.php">← Retour à l'accueil</a>
      <span class="eyebrow block">REJOINS YASMINE</span>
      <h2>Créer un compte</h2>
      <p class="muted">Inscris-toi pour découvrir ton espace sportif.</p>
      <form method="post" action="index.php?c=auth&a=register" data-validate novalidate>
        <label>Nom complet
          <input type="text" name="nom" placeholder="Ton nom complet" value="<?= e($item['nom'] ?? '') ?>" required minlength="3" maxlength="100">
          <small class="error"><?= $errors['nom'] ?? '' ?></small>
        </label>
        <label>Adresse e-mail
          <input type="email" name="email" placeholder="exemple@email.com" value="<?= e($item['email'] ?? '') ?>" required>
          <small class="error"><?= $errors['email'] ?? '' ?></small>
        </label>
        <label>Mot de passe
          <input type="password" name="mot_de_passe" placeholder="Minimum 6 caractères" required minlength="6">
          <small class="error"><?= $errors['mot_de_passe'] ?? '' ?></small>
        </label>
        <label>Objectif sportif
          <select name="objectif" required>
            <option value="">Choisir un objectif</option>
            <?php foreach ($objectifs as $k => $v): ?>
              <option value="<?= $k ?>" <?= ($item['objectif'] ?? '') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
            <?php endforeach; ?>
          </select>
          <small class="error"><?= $errors['objectif'] ?? '' ?></small>
        </label>
        <button class="btn">Créer mon compte gratuit</button>
      </form>
      <p class="muted small">Tu as déjà un compte ? <a class="green" href="index.php?c=auth&a=login">Se connecter</a></p>
    </div>
  </div>
</section>
