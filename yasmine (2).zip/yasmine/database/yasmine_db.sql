CREATE DATABASE IF NOT EXISTS yasmine_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE yasmine_db;

CREATE TABLE IF NOT EXISTS programme (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100) NOT NULL,
  objectif VARCHAR(255) NOT NULL,
  categorie ENUM('perte_poids','prise_masse','endurance','tonification','remise_en_forme') NOT NULL DEFAULT 'remise_en_forme',
  niveau ENUM('debutant','intermediaire','avance') NOT NULL,
  duree_semaines INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS exercice (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100) NOT NULL,
  description VARCHAR(150) NULL,
  type ENUM('cardio','musculation','etirement') NOT NULL,
  duree_minutes INT NOT NULL,
  calories INT NOT NULL DEFAULT 0,
  series INT NOT NULL DEFAULT 1,
  repetitions INT NOT NULL DEFAULT 1,
  image VARCHAR(255) NULL,
  id_programme INT NOT NULL,
  FOREIGN KEY (id_programme) REFERENCES programme(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS utilisateur (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  mot_de_passe VARCHAR(255) NOT NULL,
  objectif ENUM('perte_poids','prise_masse','endurance','tonification','remise_en_forme') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO programme (nom, objectif, niveau, duree_semaines) VALUES
('Perte de poids', 'Brûler des calories', 'debutant', 8),
('Prise de masse', 'Gagner du muscle', 'intermediaire', 12);
