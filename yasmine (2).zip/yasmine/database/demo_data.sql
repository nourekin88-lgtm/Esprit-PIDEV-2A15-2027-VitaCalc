-- Données de démonstration (à exécuter une seule fois)
USE yasmine_db;
UPDATE programme SET categorie='perte_poids' WHERE nom='Perte de poids';
UPDATE programme SET categorie='prise_masse' WHERE nom='Prise de masse';

INSERT INTO programme (nom, objectif, categorie, niveau, duree_semaines) VALUES
('Départ en douceur','Perdre du poids','perte_poids','debutant',4),
('Premiers muscles','Prendre du muscle','prise_masse','debutant',6),
('Force complète','Prendre du muscle','prise_masse','intermediaire',8),
('Forme au quotidien','Rester en forme','remise_en_forme','debutant',4),
('Détente et souplesse','Se détendre','tonification','debutant',4);

INSERT INTO exercice (nom, description, type, duree_minutes, calories, series, repetitions, id_programme) VALUES
('Squats','Jambes et fessiers','musculation',5,40,3,15,(SELECT id FROM programme WHERE nom='Départ en douceur' LIMIT 1)),
('Pompes','Pectoraux et bras','musculation',5,35,3,12,(SELECT id FROM programme WHERE nom='Départ en douceur' LIMIT 1)),
('Planche','Abdominaux','musculation',3,20,3,1,(SELECT id FROM programme WHERE nom='Départ en douceur' LIMIT 1)),
('Fentes','Cuisses et fessiers','musculation',5,45,3,12,(SELECT id FROM programme WHERE nom='Premiers muscles' LIMIT 1)),
('Pont fessier','Fessiers','musculation',5,30,3,15,(SELECT id FROM programme WHERE nom='Premiers muscles' LIMIT 1)),
('Pompes','Pectoraux et bras','musculation',10,60,4,15,(SELECT id FROM programme WHERE nom='Force complète' LIMIT 1)),
('Fentes','Cuisses et fessiers','musculation',8,55,4,12,(SELECT id FROM programme WHERE nom='Force complète' LIMIT 1)),
('Pont fessier','Fessiers','musculation',6,40,4,15,(SELECT id FROM programme WHERE nom='Force complète' LIMIT 1)),
('Jumping Jacks','Tout le corps','cardio',4,50,3,30,(SELECT id FROM programme WHERE nom='Forme au quotidien' LIMIT 1)),
('Montées de genoux','Cuisses et cœur','cardio',4,45,3,30,(SELECT id FROM programme WHERE nom='Forme au quotidien' LIMIT 1)),
('Étirement du dos','Dos et épaules','etirement',3,10,2,1,(SELECT id FROM programme WHERE nom='Détente et souplesse' LIMIT 1));
