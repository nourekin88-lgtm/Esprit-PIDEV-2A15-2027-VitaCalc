# Yasmine – Suivi sportif (PHP MVC + PDO)

## Installation
1. Installer XAMPP, démarrer **Apache** et **MySQL**.
2. Copier le dossier `yasmine` dans `C:\xampp\htdocs\`.
3. Ouvrir http://localhost/phpmyadmin → onglet **Importer** → choisir `database/yasmine_db.sql` → Exécuter.
4. Front Office : http://localhost/yasmine/
5. Back Office : http://localhost/yasmine/index.php?area=admin

Config base de données : `config/Database.php` (user `root`, mot de passe vide par défaut).

## Image du hero (optionnel)
Ajoutez votre propre photo dans `public/img/hero.jpg` : elle s'affichera automatiquement sur la page d'accueil.

## Inscription / Connexion
- Si la base existe déjà : importer `database/migration_utilisateur.sql` (crée la table `utilisateur`).
- Pages : `index.php?c=auth&a=register` et `index.php?c=auth&a=login`.
- Image des pages d'authentification (optionnel) : `public/img/register.jpg`.

## Mon espace (après connexion)
- Page : `index.php?c=espace` (profil sportif, exercices avec images, programmes recommandés).
- Base existante : exécuter `database/migration_espace.sql` puis `database/demo_data.sql`.
- Nouvelle installation : importer `database/yasmine_db.sql` puis `database/demo_data.sql`.
- Images des exercices : Back Office > Exercices > Modifier > « Image de l'exercice » (stockées dans `public/uploads/`).
