<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Yasmine – Suivi sportif</title>
  <link rel="stylesheet" href="public/css/style.css">
</head>
<body class="front">
<header class="topbar">
  <div class="container topbar-in">
    <a class="logo" href="index.php"><span class="logo-badge">Y</span> Yasmine</a>
    <nav class="menu">
      <a href="index.php">Accueil</a>
      <a href="index.php#decouvrir">Découvrir</a>
      <a href="index.php?c=espace">Mon espace</a>
    </nav>
    <div class="right">
      <?php if (!empty($_SESSION['user'])): ?>
        <span class="hello">👋 <?= e($_SESSION['user']['nom']) ?></span>
        <a class="btn-outline" href="index.php?c=auth&a=logout">Déconnexion</a>
      <?php else: ?>
        <a class="btn-outline" href="index.php?c=auth&a=login">Se connecter</a>
      <?php endif; ?>
    </div>
  </div>
</header>
<main><?= $content ?></main>
<footer class="footer">
  <div class="footer-in">
    <a class="logo" href="index.php"><span class="logo-badge">Y</span> Yasmine</a>
    <p>Your Health, Your Balance.</p>
    <small>© <?= date('Y') ?> Yasmine · Tous droits réservés.</small>
    <a class="muted small" href="index.php?area=admin">Administration</a>
  </div>
</footer>
<script src="public/js/validation.js"></script>
</body>
</html>
