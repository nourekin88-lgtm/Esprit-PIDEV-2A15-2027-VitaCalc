<?php
class EspaceController extends Controller {
    public const NIVEAUX = ['debutant' => 'Débutant', 'intermediaire' => 'Intermédiaire', 'avance' => 'Avancé'];
    public const TEMPS   = [15 => '15 minutes', 30 => '30 minutes', 45 => '45 minutes', 60 => '60 minutes'];

    public function index(): void {
        if (empty($_SESSION['user'])) $this->redirect('index.php?c=auth&a=login');

        $prog = new Programme();
        $profil = ['objectif' => $_SESSION['user']['objectif'] ?? '', 'niveau' => 'debutant', 'temps' => 15];
        $recherche = false;
        $liste = $prog->allWithStats();

        if (isset($_GET['objectif'])) {
            $obj = $_GET['objectif'] ?? '';
            $niv = $_GET['niveau'] ?? '';
            $tps = (int)($_GET['temps'] ?? 0);
            if (array_key_exists($obj, Programme::CATEGORIES) && isset(self::NIVEAUX[$niv]) && isset(self::TEMPS[$tps])) {
                $profil = ['objectif' => $obj, 'niveau' => $niv, 'temps' => $tps];
                $liste = $prog->recommend($obj, $niv, $tps);
                $recherche = true;
            }
        }

        $this->render('espace/index', [
            'profil' => $profil,
            'recherche' => $recherche,
            'programmes' => $liste,
            'exercices' => (new Exercice())->allWithProgramme(''),
        ], 'front');
    }
}
