<h1>Exercices</h1>
<form method="get" class="search">
  <input type="hidden" name="area" value="admin">
  <input type="hidden" name="c" value="exercice">
  <input type="text" name="q" placeholder="Rechercher un exercice..." value="<?= e($search) ?>">
  <button class="btn">Rechercher</button>
</form>
<a class="btn" href="index.php?area=admin&c=exercice&a=create">+ Nouvel exercice</a>
<table>
  <tr><th>ID</th><th>Nom</th><th>Type</th><th>Durée</th><th>Kcal</th><th>Séries × Reps</th><th>Programme</th><th>Actions</th></tr>
  <?php foreach ($items as $x): ?>
  <tr>
    <td><?= $x['id'] ?></td>
    <td><?php if (!empty($x['image'])): ?><img class="thumb" src="<?= e($x['image']) ?>" alt=""><?php endif; ?><?= e($x['nom']) ?></td>
    <td><?= e($x['type']) ?></td>
    <td><?= $x['duree_minutes'] ?> min</td>
    <td><?= $x['calories'] ?></td>
    <td><?= $x['series'] ?> × <?= $x['repetitions'] ?></td>
    <td><?= e($x['programme_nom']) ?></td>
    <td>
      <a href="index.php?area=admin&c=exercice&a=edit&id=<?= $x['id'] ?>">Modifier</a>
      <form method="post" action="index.php?area=admin&c=exercice&a=delete" style="display:inline"
            onsubmit="return confirm('Supprimer cet exercice ?')">
        <input type="hidden" name="id" value="<?= $x['id'] ?>">
        <button class="danger">Supprimer</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
