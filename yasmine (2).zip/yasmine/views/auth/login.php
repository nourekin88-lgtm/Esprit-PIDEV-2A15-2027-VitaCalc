<?php $img = file_exists(__DIR__ . '/../../public/img/register.jpg') ? 'public/img/register.jpg' : ''; ?>
<section class="auth">
  <div class="container auth-in">
    <div class="auth-img" <?= $img ? 'style="background-image:url(\'' . $img . '\')"' : '' ?>>
      <div class="auth-cap">
        <h3>Chaque effort<br>te rapproche de ton objectif.</h3>
        <small>Your Health, Your Balance.</small>
      </div>
    </div>
    <div class="auth-form">
      <a class="muted small" href="index.php">← Retour à l'accueil</a>
      <span class="eyebrow block">BON RETOUR</span>
      <h2>Se connecter</h2>
      <p class="muted">Accède à ton espace sportif.</p>
      <?php if (($_GET['registered'] ?? '') === '1'): ?>
        <p class="alert-ok">Compte créé avec succès. Connecte-toi !</p>
      <?php endif; ?>
      <?php if ($error): ?><p class="alert-ko"><?= e($error) ?></p><?php endif; ?>
      <form method="post" action="index.php?c=auth&a=login" data-validate novalidate>
        <label>Adresse e-mail
          <input type="email" name="email" placeholder="exemple@email.com" value="<?= e($email) ?>" required>
          <small class="error"></small>
        </label>
        <label>Mot de passe
          <input type="password" name="mot_de_passe" placeholder="Ton mot de passe" required>
          <small class="error"></small>
        </label>
        <button class="btn">Se connecter</button>
      </form>
      <p class="muted small">Pas encore de compte ? <a class="green" href="index.php?c=auth&a=register">Créer un compte</a></p>
    </div>
  </div>
</section>
