<h1><?= str_contains($action, 'update') ? 'Modifier' : 'Nouveau' ?> programme</h1>
<form method="post" action="<?= e($action) ?>" data-validate novalidate>
  <label>Nom
    <input type="text" name="nom" value="<?= e($item['nom'] ?? '') ?>" required minlength="3" maxlength="100">
    <small class="error"><?= $errors['nom'] ?? '' ?></small>
  </label>
  <label>Objectif
    <input type="text" name="objectif" value="<?= e($item['objectif'] ?? '') ?>" required minlength="5">
    <small class="error"><?= $errors['objectif'] ?? '' ?></small>
  </label>
  <label>Niveau
    <select name="niveau" required>
      <option value="">-- Choisir --</option>
      <?php foreach (['debutant' => 'Débutant', 'intermediaire' => 'Intermédiaire', 'avance' => 'Avancé'] as $k => $v): ?>
        <option value="<?= $k ?>" <?= ($item['niveau'] ?? '') === $k ? 'selected' : '' ?>><?= $v ?></option>
      <?php endforeach; ?>
    </select>
    <small class="error"><?= $errors['niveau'] ?? '' ?></small>
  </label>
  <label>Catégorie (pour la recommandation)
    <select name="categorie" required>
      <option value="">-- Choisir --</option>
      <?php foreach (Programme::CATEGORIES as $k => $v): ?>
        <option value="<?= $k ?>" <?= ($item['categorie'] ?? '') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
      <?php endforeach; ?>
    </select>
    <small class="error"><?= $errors['categorie'] ?? '' ?></small>
  </label>
  <label>Durée (semaines)
    <input type="number" name="duree_semaines" value="<?= e($item['duree_semaines'] ?? '') ?>" required min="1" max="52">
    <small class="error"><?= $errors['duree_semaines'] ?? '' ?></small>
  </label>
  <button class="btn">Enregistrer</button>
  <a href="index.php?area=admin&c=programme">Annuler</a>
</form>
